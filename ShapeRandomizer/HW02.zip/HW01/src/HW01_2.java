
public class HW01_2 {
	public static boolean blazerNumber(int n2) {
		int bcount=0;
		for (int i=1; i<(n2);i++) {
		if (n2%i==0) {
			bcount+=i;}}
		boolean flag = false;
		boolean tflag= true;
		if ((bcount)==n2) {
			return tflag;
		}else {
			return flag;
		}
	}
}
