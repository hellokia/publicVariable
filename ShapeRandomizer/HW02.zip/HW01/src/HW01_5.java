
public class HW01_5 {
	public static boolean grader(float avg_exams, float avg_hw, int attendance) {

		if ((attendance>20) &&((avg_hw>70)&&(avg_exams>70))&& ((avg_hw>85)|| (avg_exams>70))){
			return true;
		}else {
			return false;

	}}
}
