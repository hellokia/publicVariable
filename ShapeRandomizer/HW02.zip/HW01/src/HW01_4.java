
public class HW01_4 {
	public static int numSteps(int n) {
		int steps=0;
		steps+=1;
		if (n==0) {
			return 0;
		}else if(n%2==0) {
			return (n-1)/2;
		}else{
			return (n-1)-1;
		}
	}
}
