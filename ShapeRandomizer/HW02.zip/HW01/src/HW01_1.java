
public class HW01_1 {
	public static String divSpecial(int n1) {
		if (n1%5==0 && n1%11==0) {
			return ( "Bingo");
		}else if (n1%11==0) {
			return ("divEleven");
		}else if (n1%5==0) {
			return ("divFive");
		}else if ((prime(n1))==true) {
			return ("Go Blazers");
		}else {
			return (String.valueOf(Math.pow(n1, 3)));
		}}
	public static boolean prime (int p ) {
			for (int i= 2; i<p;i++) {
		 if (p%i==0) {
			return false;	}
		 }
		return true;
	}
		
	}

