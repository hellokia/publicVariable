import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class HW01_3 {
public static String nextDay() {
	Scanner askyear= new Scanner (System.in);
	System.out.println("Enter year:");
	int year= askyear.nextInt();
	Scanner askmonth= new Scanner(System.in);
	System.out.println("Enter month:");
	int month= askmonth.nextInt();
	Scanner askday= new Scanner(System.in);
	System.out.println("Enter day:");
	int day= askday.nextInt();
	askyear.close();
	askmonth.close();
	askday.close();
	ArrayList<Integer> mwtod= new ArrayList <>(Arrays.asList(1,3,5,7,8,10,12));
	ArrayList<Integer> mwtd= new ArrayList <>(Arrays.asList(4,6,9,11));
	if (month==12 && day==31) {
		return ("The next date is "+String.valueOf(year+1)+"-"+String.valueOf(month=1)+"-"+String.valueOf(day=1));
	}else if (mwtod.contains(month) && day==31) {
		return ("The next date is "+String.valueOf(year)+"-"+String.valueOf(month+1)+"-"+String.valueOf(day=1));
	}else if (mwtod.contains(month) && day<=30) {
		return ("The next date is "+String.valueOf(year)+"-"+String.valueOf(month)+"-"+String.valueOf(day+1));
	}else if (mwtd.contains(month) && day==30) {
		return("The next date is "+String.valueOf(year)+"-"+String.valueOf(month+1)+"-"+String.valueOf(day=1));
	}else if (mwtd.contains(month) && day<=30) {
		return("The next date is "+String.valueOf(year)+"-"+String.valueOf(month)+"-"+String.valueOf(day+1));
	}else if (month==(2) && day==28) {
		return ("The next date is "+String.valueOf(year)+"-"+String.valueOf(month+1)+"-"+String.valueOf(day=1));
	}else if (month==(2) && day<=27) {
		return ("The next date is "+String.valueOf(year)+"-"+String.valueOf(month)+"-"+String.valueOf(day+1));
	}else {
		return ("Invalid month or day entered. Please use valid date. Try 1-12 for months and 1-31 for days.");
		
	}}}