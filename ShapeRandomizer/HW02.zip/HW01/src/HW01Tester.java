
public class HW01Tester {
	public static void main (String [] args) {
		System.out.println("Question 1:");
		System.out.println(HW01_1.divSpecial(15));
		System.out.println(HW01_1.divSpecial(77));
		System.out.println(HW01_1.divSpecial(110));
		System.out.println(HW01_1.divSpecial(17));
		System.out.println("Question 2:");
		System.out.println(HW01_2.blazerNumber(28));
		System.out.println(HW01_2.blazerNumber(12));
		System.out.println(HW01_2.blazerNumber(6));
		System.out.println(HW01_2.blazerNumber(27));
		System.out.println("Question 3:");
		System.out.println(HW01_3.nextDay());
			System.out.println("Question 4:");
		System.out.println(HW01_4.numSteps(14));
		System.out.println("Question 5:");
		if (HW01_5.grader(72,88,22)==true) {
			System.out.println("PASS");
		}else if (HW01_5.grader(72,88,22)==true) {
			System.out.println("FAIL");
		}
		if (HW01_5.grader(66,100,24)==true) {
			System.out.println("PASS");
		}else if (HW01_5.grader(72,88,22)==true) {
			System.out.println("FAIL");
		}
		if (HW01_5.grader(100,80,18)==true) {
			System.out.println("PASS");
		}else if (HW01_5.grader(72,88,22)==true) {
			System.out.println("FAIL");
		}
	
		

		


	}
	}
